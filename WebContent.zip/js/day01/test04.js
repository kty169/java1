var str = '';
var str1 = '';

for(ava = 1 ; ava < 4 ; ava++){
	let mtp = '<div class="inblock w3-margin">' +
					'<img src="../img/img_avatar' + ava + '.png" class="w150">' +
					'<div>' + '아바타' + ava + '</div>' ;
	mtp = mtp +	'</div>' +
			'</div>' ;
	str = str + mtp;
}
for(ava = 4 ; ava < 7 ; ava++){
	let mtp = '<div class="inblock w3-margin">' +
					'<img src="../img/img_avatar' + ava + '.png" class="w150">' +
					'<div>' + '아바타' + ava + '</div>' ;
	mtp = mtp +	'</div>' +
			'</div>' ;
	str1 = str1 + mtp;
}

document.getElementById('board1').innerHTML = str; 
document.getElementById('board2').innerHTML = str1; 
