/*
	자바스크립트에서 함수 만드는 방법
	
	 방법 1 ]
	
			function 함수이름([매개변수리스트]){
				실행내용
			}
			
	 방법 2 ]
			var 함수이름 = function([매개변수리스트]){
				실행내용...
			};
*/

function tell(){
	var name = 'jennie';
	
	alert(name);
}