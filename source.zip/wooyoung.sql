DELETE
from
    emp1
where
    ename = 'wooyoung'
;

SELECT
    rno, mno, name, hdate, dno
FROM
(
    SELECT
        ROWNUM rno, mno, name, hdate, dno
    FROM
    (
        SELECT
            empno mno, ename name, hiredate hdate, deptno dno
        FROM
            emp1
        ORDER BY 
            empno
    )
)
WHERE
    rno BETWEEN 5 AND 8
;

-- �� ����� ��ȸ
SELECT
    COUNT(*) cnt
FROM
    emp1
;