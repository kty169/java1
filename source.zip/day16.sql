-- day16

/*
    데이터베이스 설계
    
        1. 개념적 설계
            ==> Entity에 대한 정의를 개념적으로 하는 단계
                Entity가 갖는 속성을 정의하는 단계
                
                ER Model Diagram
                
        2. 논리적 설계
            ==> Entity 간의 관계를 논리적으로 정의하는 단계
            
                ERD
                
        3. 물리적 설계
            ==> 실제 데이터베이스에 만들어질 형태로 설계를 하는 단계
                
                실제 구현될 테이블의 이름과 필드의 이름이 확정이 된다.
                입력되야할 데이터의 타입과 크기, 제약조건 등이 만들어져야 한다.
                
                테이블명세서, DDL 명령
                
    ----------------------------------------------------------------------------
    
    정규화
        
        1. 제1 정규화
            ==> 개체가 가지는 모든 속성은 더이상 분리되지 않는 원자값을 가져야 한다.
            
                ==> 되도록 더이상 분리 못할 때까지 속성을 분리하세요.
                
        2. 제2 정규화
            ==> 기본키에 대해서 기본키 이외의 속성들은 완전함수 종속이어야 한다.
            
                ==> 기본키 주세요.
        3. 제3 정규화
            ==> 이행적 함수 종속에서 벗어나야 한다.
            
                
        4. BCNF 정규화...
    
--------------------------------------------------------------------------------

게시판을 설계해보자
    
    작업 순서
        1. 개념적 설계
            ==> ER Model Diagram
        2. 논리적 설계
            ==> ERD
        3. 물리적 설계
            ==> 테이블명세서, DDL명령
    
    요구사항
        ==> 인터뷰
        
    요구사항 분석 ]
        ==> 개념적 설계
            
            
        
*/

/*
    게시판 요구사항 ]
        1. 게시판은 회원이 작성해서 게시하는 글을 모아놓은 것이다.
        2. 게시글은 제목을 입력해야하고 작성자, 내용, 작성일, 조회수를 기록해야 한다.
        3. 조회수는 한번 조회할 때마다 누적 수정이 되어야 한다.
        4. 게시글은 수정할 수 있다.
            이때 수정 시간은 매번 기록하기로 한다.
            내용은 기록하지 않고 시간만 기록하시로 한다.
        5. 게시글은 분류를 해서 카테고리를 갖도록 한다.
        6. 분류는 분류이름, 분류코드 만 갖는 것으로 한다.
        7. 게시글은 첨부파일을 첨부할 수 있다.
        8. 게시글은 검색기능으로 검색할 수 있어야 한다.
            검색은 제목과 내용, 작성자, 작성일로 검색 가능하게 한다.
        9. 게시글 리스트는 페이지당 10개씩 보여지도록 한다.
        10. 공지사항은 모든 페이지 맨 앞부분에 위치하도록 한다.
        11. 댓글작성이 가능하도록 한다.
        12. 게시글은 추천수, 비추천수를 가지도록 한다.
            
*/
ALTER TABLE member
ADD CONSTRAINT MEMB_MNO_PK PRIMARY KEY(mno);
-- 분류 테이블
CREATE TABLE category(
    cateNo NUMBER(2)
        CONSTRAINT CATE_NO_PK PRIMARY KEY,
    cateName VARCHAR2(10 CHAR)
        CONSTRAINT CATE_NAME_UK UNIQUE
        CONSTRAINT CATE_NAME_NN NOT NULL
);

-- 게시글 정보 테이블
CREATE TABLE board(
    bno NUMBER(6)
        CONSTRAINT BRD_NO_PK PRIMARY KEY,
    title VARCHAR2(100 CHAR)
        CONSTRAINT BRD_TTL_NN NOT NULL,
    body VARCHAR2(4000)
        CONSTRAINT BRD_BODY_NN NOT NULL,
    upno NUMBER(6),
    writer NUMBER(4)
        CONSTRAINT BRD_WRITER_FK REFERENCES member(mno)
        CONSTRAINT BRD_WRITER_NN NOT NULL,
    wdate DATE DEFAULT sysdate
        CONSTRAINT BRD_DATE_NN NOT NULL,
    wcount NUMBER(6) DEFAULT 0
        CONSTRAINT BRD_CNT_NN NOT NULL,
    cate NUMBER(2)
        CONSTRAINT BRD_CATE_FK REFERENCES category(cateNo)
        CONSTRAINT BRD_CATE_NN NOT NULL,
    isShow CHAR(1) DEFAULT 'Y'
        CONSTRAINT BRD_SHOW_CK CHECK(isShow IN('Y','N'))
        CONSTRAINT BRD_SHOW_NN NOT NULL
);

-- 추천 이력 정보
CREATE TABLE recommend(
    rcno NUMBER(8)
        CONSTRAINT RCMD_NO_PK PRIMARY KEY,
    rbno NUMBER(6)
        CONSTRAINT RCMD_BNO_FK REFERENCES board(bno)
        CONSTRAINT RCMD_BNO_NN NOT NULL,
    rmno NUMBER(4)
        CONSTRAINT RCMD_MNO_FK REFERENCES member(mno)
        CONSTRAINT RCMD_MNO_NN NOT NULL,
    rdate DATE DEFAULT sysdate
        CONSTRAINT RCMD_DATE_NN NOT NULL,
    rcode CHAR(1)
        CONSTRAINT RCMD_CODE_CK CHECK(rcode IN('G','B'))
        CONSTRAINT RCMD_CODE_NN NOT NULL
);

-- 첨부파일 정보 테이블
CREATE TABLE fileInfo(
    fno NUMBER(8)
        CONSTRAINT FI_NO_PK PRIMARY KEY,
    fbno NUMBER(6)
        CONSTRAINT FI_BNO_FK REFERENCES board(bno)
        CONSTRAINT FI_BNO_NN NOT NULL,
    oriname VARCHAR2(50 CHAR)
        CONSTRAINT FI_ONAME_NN NOT NULL,
    savename VARCHAR2(50 CHAR)
        CONSTRAINT FI_SNAME_UK UNIQUE
        CONSTRAINT FI_SNAME_NN NOT NULL,
    uptime DATE DEFAULT sysdate
        CONSTRAINT FI_DATE_NN NOT NULL
);

-- 게시글 수정 이력 정보 테이블
CREATE TABLE editInfo(
    eino NUMBER(6)
        CONSTRAINT EI_NO_PK PRIMARY KEY,
    ebno NUMBER(6)
        CONSTRAINT EI_BNO_FK REFERENCES board(bno)
        CONSTRAINT EI_BNO_NN NOT NULL,
    etitle VARCHAR2(100 CHAR)
        CONSTRAINT EI_TTL_NN NOT NULL,
    ebody VARCHAR2(4000)
        CONSTRAINT EI_BODY_NN NOT NULL,
    edate DATE DEFAULT sysdate
        CONSTRAINT EI_DATE_NN NOT NULL
);