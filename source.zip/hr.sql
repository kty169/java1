SELECT * FROM jspbbs WHERE no =15;

INSERT INTO jspbbs(no, title, writer, content, reg_date,read_count, pass, file1)
    values(jspbbs_seq.NEXTVAL, '제목','글쓴이', ' 게시 글 내용', SYSDATE, 0, '1234', null);
    
SELECT * FROM jspbbs ORDER BY no DESC;
ROLLBACK;

UPDATE jspShoes SET sname = 'asda', brand = ' asdad', sal= 123, content= ' afaksdflasdfl' WHERE no=15; 
ROLLBACK;